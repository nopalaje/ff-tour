# 🎮 FF Tournament Online — Panduan Deploy

## Apa yang Didapat
- **PWA** (Progressive Web App) — bisa di-install di HP Android/iPhone
- **Realtime** — semua tim lihat update langsung tanpa refresh
- **Supabase backend** — database gratis, tanpa server sendiri
- Login **admin** (bisa edit) dan **viewer** (hanya lihat)

---

## 📋 Langkah 1: Setup Supabase (Gratis, Sekali Saja)

1. Buka [supabase.com](https://supabase.com) → buat akun
2. Klik **"New Project"** → isi nama & password → Create
3. Tunggu ±1 menit sampai project siap
4. Masuk ke **SQL Editor** (menu kiri)
5. Copy paste SQL berikut → klik **Run**:

```sql
-- Buat tabel tournament
CREATE TABLE ff_tournament (
  id TEXT PRIMARY KEY DEFAULT 'main',
  data JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Buat tabel auth
CREATE TABLE ff_auth (
  id TEXT PRIMARY KEY DEFAULT 'main',
  data JSONB NOT NULL
);

-- Insert data awal
INSERT INTO ff_tournament (id, data)
VALUES ('main', '{"pots":[],"curPot":0}')
ON CONFLICT DO NOTHING;

INSERT INTO ff_auth (id, data)
VALUES ('main', '{"admin":{"password":"admin123"},"viewer":{"password":"lihat123"}}')
ON CONFLICT DO NOTHING;

-- Enable public access
ALTER TABLE ff_tournament ENABLE ROW LEVEL SECURITY;
ALTER TABLE ff_auth ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public" ON ff_tournament FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "public" ON ff_auth FOR ALL USING (true) WITH CHECK (true);
```

6. Masuk ke **Settings → API**
7. Copy **Project URL** dan **anon public key**

---

## 📋 Langkah 2: Deploy Aplikasi

### Opsi A: GitHub Pages (Paling Mudah, Gratis)

1. Buat akun [github.com](https://github.com) kalau belum punya
2. Buat repository baru → nama bebas → Public
3. Upload semua file dari folder `ff_tournament_pwa/`:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icons/icon-192.png`
   - `icons/icon-512.png`
4. Masuk ke **Settings → Pages**
5. Source: **Deploy from branch** → branch: `main` → folder: `/ (root)`
6. Klik Save → tunggu ±1 menit
7. Alamat app: `https://username-kamu.github.io/nama-repo/`

### Opsi B: Netlify (Drag & Drop, Gratis)

1. Buka [netlify.com](https://netlify.com) → login/daftar
2. Drag & drop folder `ff_tournament_pwa/` ke halaman Netlify
3. Dapat URL langsung! Contoh: `https://amazing-name-123.netlify.app`

### Opsi C: Simpan di HP (Tanpa Hosting)

Buka `index.html` langsung dari HP (via file manager/browser).
Data tetap tersimpan di Supabase, tapi tidak bisa diinstall sebagai PWA.

---

## 📋 Langkah 3: Pertama Kali Buka App

1. Buka URL app di browser HP
2. Muncul halaman **Setup** → masukkan:
   - **Supabase URL**: `https://xxxxx.supabase.co`
   - **Anon Key**: `eyJhbGci...`
3. Klik **Mulai Tournament** → akan langsung ke halaman login
4. Data konfigurasi tersimpan di browser — tidak perlu input ulang

---

## 📋 Install di HP (PWA)

### Android (Chrome):
1. Buka URL app di Chrome
2. Klik menu ⋮ (titik tiga) → **"Tambahkan ke layar utama"**
3. Klik **Tambahkan** → app muncul di home screen!

### iPhone (Safari):
1. Buka URL app di Safari
2. Klik tombol **Share** (kotak dengan panah ke atas)
3. Scroll → pilih **"Add to Home Screen"**
4. Klik **Add**

---

## 🔐 Default Login

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | Admin (bisa edit) |
| `viewer` | `lihat123` | Viewer (hanya lihat) |

> **PENTING**: Ganti password setelah pertama login!
> Masuk ke icon 👤 → Ganti Password

---

## 🔗 Share ke Tim

Setelah deploy, share URL ke tim kamu:
- **Admin**: satu orang saja yang login sebagai admin
- **Viewer**: semua anggota tim lain login sebagai viewer
- Data update **realtime** — viewer langsung lihat perubahan skor

---

## 🛠 Troubleshooting

**"Gagal konek" saat setup:**
- Pastikan SQL sudah dijalankan di Supabase
- Cek URL format: `https://xxxxx.supabase.co` (tanpa slash di akhir)
- Cek Anon Key benar (ambil dari Settings → API → anon public)

**Data tidak muncul:**
- Cek koneksi internet
- Refresh halaman
- Coba logout → login ulang

**Tidak bisa install PWA:**
- Harus via HTTPS (GitHub Pages / Netlify sudah otomatis HTTPS)
- Tidak bisa install dari `file://` atau `http://`
